import openai
import gradio

openai.api_key = "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"

# Initialize BARD model (example, replace with actual BARD model)
def retrieve_context(user_input):
    # Your code to retrieve context using BARD
    # This could involve querying a large corpus of text data
    # and identifying relevant documents or information
    context = "Placeholder context retrieved by BARD for user input: {}".format(user_input)
    return context

def CustomChatGPT(user_input):
    # Retrieve context using BARD
    context = retrieve_context(user_input)
    
    # Generate response using ChatGPT with context
    response = openai.Completion.create(
        engine="gpt-3.5-turbo",  # Using a smaller engine for better cost efficiency
        prompt=context + "\nUser: " + user_input + "\nAI:",
        temperature=0.7,
        max_tokens=150,
        top_p=1.0,
        frequency_penalty=0.0,
        presence_penalty=0.0
    )
    ChatGPT_reply = response.choices[0].text.strip()
    
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs="text", outputs="text", title="Chatbot with BARD and ChatGPT")

demo.launch(share=True)
